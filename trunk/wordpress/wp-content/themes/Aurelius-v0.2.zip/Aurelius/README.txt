This theme is based on the work from QwibbleDesigns's Aurelius. His profile is on http://themeforest.net/user/QwibbleDesigns.
You can use this theme for whatever you want, but please keep the reference back to us. 
Please contact us, if you want to use it for commercial, and remove the link.

There is a step by step tutorial on how to install and use this theme in my website pengbos.com.
If you still have problems after viewing the tutorial, please contact me directly.
My email address is pengbos.com@gmail.com or pengbos@hotmail.com

Thanks for downloading.