<!-- Footer -->
<p class="grid_12 footer clearfix">
    <span class="float"><b>&copy; Copyright</b> <a href="www.pengbos.com">Pengbos.com</a> <b>Designed by</b> <a href="http://themeforest.net/user/QwibbleDesigns">QwibbleDesigns</a>- remove upon purchase.</span>
    <a class="float right" href="#">top</a>
</p>

</div><!--end wrapper-->
<?php wp_footer(); ?>
</body>
</html>