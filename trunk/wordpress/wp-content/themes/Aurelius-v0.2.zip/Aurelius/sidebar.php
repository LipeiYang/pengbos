
<h4>Catagories:</h4>
<ul class="sidebar">
    <?php wp_list_cats(); ?>
</ul>

<h4>Archives:</h4>
<ul class="sidebar">
    <?php wp_get_archives('type=monthly'); ?>
</ul>
